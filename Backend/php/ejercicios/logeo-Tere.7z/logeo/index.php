<?php
header('Location: pag-principal.php');

?>

